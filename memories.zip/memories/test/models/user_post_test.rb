require 'test_helper'

class UserPostTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
